import { handleCommand } from "./commandHandler.js";
import { handleInstalled } from "./installedHandler.js";
import { handleMessage } from "./messageHandler.js";

chrome.commands.onCommand.addListener(handleCommand);
chrome.runtime.onInstalled.addListener(handleInstalled);
chrome.runtime.onMessage.addListener(handleMessage);
