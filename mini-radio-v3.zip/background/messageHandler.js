import { closeOffscreenDocument, createOffscreenDocument, hasOffscreenDocument } from './utils/offscreen.js';
import { sendMessage, withErrorHandling } from '../utils/extension.js';
import { ACTIONS, STATES } from '../constants/constant.js';
import { setBadgeFromAudioState } from './utils/badge.js';
import { sendAnalytics, buildProxyUrl, validateStream } from './utils/network.js';
import {
  moveToTopOfHistory,
  resetCustomStation,
  resetHistory,
  resetVolume,
  getCustomStation,
  getVolume,
  getStations,
  setCustomStation,
  setVolume,
  setCustomStationInHistory
} from './utils/storage.js';

async function playStation(station) {
  const { id, hls, src, name } = station;
  const volume = await getVolume();

  if (!await hasOffscreenDocument()) {
    await createOffscreenDocument();
  }

  if (id !== 0) {
    if (hls) {
      sendAnalytics(name);
    } else {
      station.src = await buildProxyUrl(src, name);
    }
  }

  await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station, volume });
  await moveToTopOfHistory(id);
}

async function maybeCloseOffscreenForCustom(station) {
  if (station.id === 0 && await hasOffscreenDocument()) {
    await closeOffscreenDocument();
  }
}

export function handleMessage(request, sender, sendResponse) {
  const handler = actions[request.action];

  if (handler) {
    return handler({ request, sender, sendResponse });
  }

  return false;
}

export const actions = {
  [ACTIONS.POPUP_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    const stations = await getStations();

    let state = STATES.STOPPED;
    if (await hasOffscreenDocument()) {
      state = await sendMessage(ACTIONS.OFFSCREEN_IS_PLAYING) || {};
    }

    await sendResponse({ state, stations });
  }),

  [ACTIONS.OPTIONS_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    const station = await getCustomStation();
    const volume = await getVolume();

    sendResponse({ station, volume });
  }),

  [ACTIONS.POPUP_PLAY_STREAM]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_PLAY_STREAM]: withErrorHandling(async ({ sendResponse }) => {
    const station = await getCustomStation();
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_SET_CUSTOM_STATION]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    const { src } = await getCustomStation();

    // Validate only if the URL has changed
    if (station.src && station.src !== src) {
      const validate = await validateStream(station.src);

      if (!validate.ok) {
        sendResponse({ success: false, error: validate.error || validate.reason });
        return;
      }

      station.hls = validate.hls || false;
      station.src = validate.url || station.src;

      // Close offscreen if custom station URL changed
      await maybeCloseOffscreenForCustom(station);
    }

    await setCustomStation(station);
    await setCustomStationInHistory();

    sendResponse({ success: true, station});
  }),

  [ACTIONS.OPTIONS_SET_VOLUME]: withErrorHandling(async ({ request, sendResponse }) => {
    const { volume } = request;

    await setVolume(volume);

    if (await hasOffscreenDocument()) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, { volume });
    }

    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_RESET_ITEMS]: withErrorHandling(async ({ request, sendResponse }) => {
    const { items } = request;

    const needsOffscreenClose = items.includes("custom_station") || items.includes("history");
    if (needsOffscreenClose && await hasOffscreenDocument()) {
      await closeOffscreenDocument();
    }

    const results = {};
    const resetActions = {
      custom_station: resetCustomStation,
      history: resetHistory,
      volume: resetVolume,
    };

    for (const item of items) {
      const action = resetActions[item];

      if (action) {
        results[item] = await action();
      } else {
        console.warn(`Reset not supported for: ${item}`);
      }
    }
    sendResponse({ success: true, results });
  }),

  [ACTIONS.OFFSCREEN_STATE_CHANGED]: withErrorHandling(async ({ request, sendResponse }) => {
    const { state } = request;

    if (state === STATES.ERROR) {
      await closeOffscreenDocument();
    }

    await setBadgeFromAudioState(state);
    sendResponse({ success: true });
  }),
};
