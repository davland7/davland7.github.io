import { WORKER } from '../../constants/constant.js';
import { getClientAndSessionBody } from './storage.js';

/**
 * Creates an AbortController with timeout
 * @param {number} ms - Timeout in milliseconds
 * @returns {AbortController}
 */
function createTimeoutController(ms) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ms);

  // Store timeout ID for cleanup
  controller.timeoutId = timeout;

  return controller;
}

export async function buildProxyUrl(url, name) {
  const ids = await getClientAndSessionBody();

  const params = new URLSearchParams({
    url,
    name,
    ...ids
  });

  return `${WORKER.URL_BASE}${WORKER.PROXY}?${params.toString()}`;
}

export async function sendAnalytics(name) {
  const controller = createTimeoutController(4000);

  try {
    const ids = await getClientAndSessionBody();
    const body = { ...ids, name };

    const response = await fetch(`${WORKER.URL_BASE}${WORKER.ANALYTICS}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });

    if (!response.ok) {
      console.warn("Analytics failed:", response.statusText);
      return null;
    }

    return await response.json();
  } catch (error) {
    console.warn("Analytics error:", error);
    return null;
  } finally {
    clearTimeout(controller.timeoutId);
  }
}

export async function validateStream(url) {
  const controller = createTimeoutController(5000);

  try {
    const ids = await getClientAndSessionBody();
    const params = new URLSearchParams({
      url,
      ...ids
    });

    const response = await fetch(
      `${WORKER.URL_BASE}${WORKER.VALIDATE}?${params.toString()}`,
      { signal: controller.signal }
    );

    return await response.json();
  } catch (error) {
    console.warn("validateStream error:", error);
    return { ok: false, fallback: true, reason: "validate_error" };
  } finally {
    clearTimeout(controller.timeoutId);
  }
}
