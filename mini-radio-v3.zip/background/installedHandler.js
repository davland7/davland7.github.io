import { initData, migrateToV3 } from "./utils/storage.js";
import { getLangCode } from "../utils/i18n.js";

export async function handleInstalled(details) {
  const isInstall = details.reason === "install";
  const isUpdateFromV2 = details.reason === "update" && details.previousVersion?.startsWith("2.");

  if (isInstall || isUpdateFromV2) {
    chrome.tabs.create({ url: chrome.runtime.getURL(`welcome.html#${getLangCode()}`) });
    await initData();

    if (isUpdateFromV2) {
      await migrateToV3();
    }
  }
}
